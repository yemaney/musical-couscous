import { CloudSetupWizard } from "@/components/cloud-setup-wizard"

export default function Page() {
  return <CloudSetupWizard />
}
